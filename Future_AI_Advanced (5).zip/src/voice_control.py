import pyttsx3

class VoiceAssistant:
    def __init__(self):
        self.engine = pyttsx3.init()

    def activate(self):
        print("🔊 نظام التحكم الصوتي مفعل!")
        self.engine.say("Hello, I am your AI assistant.")
        self.engine.runAndWait()

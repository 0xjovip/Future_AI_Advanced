class CloudAI:
    def connect(self):
        print("☁️ الاتصال بالذكاء الاصطناعي السحابي.")

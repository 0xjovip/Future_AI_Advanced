from ai_core import FutureAI

def main():
    ai_system = FutureAI()
    ai_system.start()

if __name__ == "__main__":
    main()

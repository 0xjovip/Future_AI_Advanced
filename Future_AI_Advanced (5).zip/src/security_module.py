import face_recognition

class SecuritySystem:
    def activate_protection(self):
        print("🔒 تفعيل الحماية باستخدام التعرف على الوجه.")

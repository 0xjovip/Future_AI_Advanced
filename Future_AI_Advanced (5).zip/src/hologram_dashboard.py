class HologramUI:
    def launch(self):
        print("🌌 تشغيل لوحة التحكم الهولوجرامية.")
